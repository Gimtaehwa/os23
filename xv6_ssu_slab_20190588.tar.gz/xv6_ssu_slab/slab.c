#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

struct {
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;

void slabinit(){
	int i;

	initlock(&stable.lock, "slab");
	
	for(i = 0; i < NSLAB; i++){
		stable.slab[i].bitmap = (char *) kalloc();
		memset(stable.slab[i].bitmap, 0, PGSIZE);
	}

	for(i = 0; i < NSLAB; i++){
		stable.slab[i].page[0] = kalloc();
		stable.slab[i].size = 1 << (i + 3);
		stable.slab[i].num_pages = 1;
		stable.slab[i].num_objects_per_page = PGSIZE / stable.slab[i].size;
		stable.slab[i].num_free_objects = stable.slab[i].num_objects_per_page;
		stable.slab[i].num_used_objects = 0;
		memset(stable.slab[i].page[0], 0, PGSIZE);
	}
}

char *kmalloc(int size){
    acquire(&stable.lock);
    
	int i;
	for (i = 0; (1 << (i+3)) < size && i < NSLAB; i++) {}

	if (stable.slab[i].num_free_objects == 0){
		
		if (stable.slab[i].num_pages >= MAX_PAGES_PER_SLAB) {
			release(&stable.lock);
			return 0x00;
		}
		char *new_page = kalloc();

		stable.slab[i].page[stable.slab[i].num_pages] = new_page;
		stable.slab[i].num_pages++;
		stable.slab[i].num_free_objects += stable.slab[i].num_objects_per_page;
		
		memset(new_page, 0, PGSIZE);
	}

	if (stable.slab[0].num_used_objects > 32767) {
		release(&stable.lock);
		return 0x00;
	}
	
	int j;
	for (j = 0; j < PGSIZE; j++){
		if (stable.slab[i].bitmap[j] == 0) {
			stable.slab[i].bitmap[j] = 1;
			stable.slab[i].num_free_objects--;
			stable.slab[i].num_used_objects++;
			
			int current_page = j / stable.slab[i].num_objects_per_page;
			int current_object = j % stable.slab[i].num_objects_per_page;
			char *base = stable.slab[i].page[current_page];

			release(&stable.lock);
			return base + current_object * stable.slab[i].size;
		}
	}

	release(&stable.lock);
	return 0x00;
}

void kmfree(char *addr, int size){
    acquire(&stable.lock);
	
	// find NSLAB index
	int i;
    for (i = 0; (1 << (i+3)) < size && i < NSLAB; i++) {}
	
	// find NUM_PAGE
	int j;
    for (j = 0; j < stable.slab[i].num_pages; j++) {
        if (addr >= stable.slab[i].page[j] && addr < stable.slab[i].page[j] + PGSIZE) {
            break;
        }
    }

	//slab object 초기화
	memset(addr, 0, size);
	

	//비트맵 초기화

	int k = (addr - stable.slab[i].page[j]) / stable.slab[i].size;
	stable.slab[i].bitmap[k / 8] = 0;
	stable.slab[i].num_free_objects++;
    stable.slab[i].num_used_objects--;

    release(&stable.lock);
}


void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}

int numobj_slab(int slabid)
{
	return stable.slab[slabid].num_used_objects;
}
